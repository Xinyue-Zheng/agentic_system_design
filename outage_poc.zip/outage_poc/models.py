"""Immutable contracts shared by the synthetic provider, state engine and UI."""

from dataclasses import dataclass
from typing import Literal

Coordinate = tuple[float, float]


@dataclass(frozen=True)
class Task:
    down_cell_id: str
    outage_time: str
    objective: str


@dataclass(frozen=True)
class GridPoint:
    id: str
    x_m: float
    y_m: float
    column: int
    row: int


@dataclass(frozen=True)
class Geometry:
    kind: Literal["polygon", "polyline", "buffer"]
    coordinates: tuple[Coordinate, ...]
    buffer_width_m: float | None


@dataclass(frozen=True)
class GeoObject:
    id: str
    kind: Literal[
        "settlement", "highway", "farmland", "vineyard", "forest", "study_area", "cell"
    ]
    description: str
    geometry: Geometry


@dataclass(frozen=True)
class SpatialRelation:
    subject_id: str
    predicate: str
    object_id: str
    evidence: str


@dataclass(frozen=True)
class GeographicReference:
    id: str
    description: str
    geometry: Geometry
    grid_ids: tuple[str, ...]
    parent_id: str | None


@dataclass(frozen=True)
class Signal:
    cell_id: str
    rsrp_dbm: float
    rsrq_db: float


@dataclass(frozen=True)
class CoverageRecord:
    grid_id: str
    status: Literal["valid", "missing"]
    cells: tuple[Signal, ...]
    # Synthetic demand assigned to the down cell, not population inferred from land use.
    down_cell_traffic_mbps: float | None


@dataclass(frozen=True)
class BaselineKPI:
    cell_id: str
    baseline_prb_percent: float
    capacity_mbps: float


@dataclass(frozen=True)
class Dataset:
    task: Task
    grid_spacing_m: float
    grid: tuple[GridPoint, ...]
    geography: tuple[GeoObject, ...]
    relations: tuple[SpatialRelation, ...]
    references: tuple[GeographicReference, ...]
    records: tuple[CoverageRecord, ...]
    baseline_kpis: tuple[BaselineKPI, ...]


@dataclass(frozen=True)
class QueryParameters:
    reference_id: str
    geometry: Geometry
    grid_ids: tuple[str, ...]
    coordinate_system: str
    coverage_epoch: str


@dataclass(frozen=True)
class CoverageObservation:
    id: str
    source: Literal["synthetic"]
    parameters: QueryParameters
    result_status: Literal["complete", "partial_missing", "all_missing"]
    records: tuple[CoverageRecord, ...]


@dataclass(frozen=True)
class ObservationLink:
    observation_id: str
    path: str
    reference_id: str
    grid_ids: tuple[str, ...]


@dataclass(frozen=True)
class GridEvidence:
    grid_id: str
    observation_id: str


@dataclass(frozen=True)
class RegionSummary:
    reference_id: str
    total_ids: tuple[str, ...]
    queried_ids: tuple[str, ...]
    unqueried_ids: tuple[str, ...]
    valid_ids: tuple[str, ...]
    missing_ids: tuple[str, ...]
    valid_covered_ids: tuple[str, ...]
    no_coverage_ids: tuple[str, ...]
    # Valid locations with cells, but without the target. Not the same as no coverage.
    other_cells_only_ids: tuple[str, ...]
    target_ids: tuple[str, ...]
    target_rsrp_min_dbm: float | None
    target_rsrp_max_dbm: float | None
    boundary_ids: tuple[str, ...]
    boundary_valid_ids: tuple[str, ...]
    boundary_missing_ids: tuple[str, ...]
    boundary_target_ids: tuple[str, ...]
    observation_ids: tuple[str, ...]


@dataclass(frozen=True)
class BackupAssignment:
    grid_id: str
    backup_cell_id: str | None
    classification: Literal["transferred", "no_eligible_backup"]
    traffic_mbps: float


@dataclass(frozen=True)
class BackupLoad:
    cell_id: str
    assigned_locations: int
    location_share: float
    transferred_mbps: float
    traffic_share: float
    baseline_prb_percent: float
    capacity_mbps: float
    estimated_prb_percent: float
    exceeds_capacity: bool


@dataclass(frozen=True)
class LoadParameters:
    scope_reference_id: str
    minimum_rsrp_dbm: float
    minimum_rsrq_db: float
    selection_rule: str
    load_formula: str


@dataclass(frozen=True)
class ImpactAnalysis:
    source: Literal["synthetic"]
    parameters: LoadParameters
    scope_queried_ids: tuple[str, ...]
    excluded_missing_ids: tuple[str, ...]
    excluded_unqueried_ids: tuple[str, ...]
    target_location_count: int
    total_target_traffic_mbps: float
    unserved_traffic_mbps: float
    assignments: tuple[BackupAssignment, ...]
    backup_loads: tuple[BackupLoad, ...]
    baseline_kpis: tuple[BaselineKPI, ...]
    limitations: tuple[str, ...]


@dataclass(frozen=True)
class State:
    id: str
    source: Literal["synthetic"]
    task: Task
    coordinate_system: str
    grid_spacing_m: float
    grid: tuple[GridPoint, ...]
    geography: tuple[GeoObject, ...]
    relations: tuple[SpatialRelation, ...]
    references: tuple[GeographicReference, ...]
    regions: tuple[RegionSummary, ...]
    observations: tuple[ObservationLink, ...]
    evidence: tuple[GridEvidence, ...]
    impact: ImpactAnalysis | None
    unknowns: tuple[str, ...]


@dataclass(frozen=True)
class Action:
    tool: Literal["coverage.query", "impact.estimate"]
    parameters: QueryParameters | LoadParameters


@dataclass(frozen=True)
class Step:
    id: str
    execution_source: Literal["scripted_demo"]
    state_before: str
    context_preview: str
    action: Action
    observation: str
    state_after: str
    context_after: str
    visualization: str


@dataclass(frozen=True)
class Trace:
    source: Literal["synthetic"]
    execution_source: Literal["scripted_demo"]
    description: str
    initial_state: str
    fixed_skill: str
    steps: tuple[Step, ...]
