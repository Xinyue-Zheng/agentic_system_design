"""Plain JSON output and explicit decoding of the synthetic observation contract."""

import json
from dataclasses import asdict
from math import isfinite
from pathlib import Path
from typing import cast

from outage_poc.models import (
    CoverageObservation,
    CoverageRecord,
    Dataset,
    Geometry,
    ImpactAnalysis,
    QueryParameters,
    Signal,
    State,
    Step,
    Trace,
)

type Artifact = Dataset | State | Step | Trace | CoverageObservation | ImpactAnalysis


def write_json(path: Path, artifact: Artifact) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(asdict(artifact), indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _object(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        raise ValueError("Expected a JSON object")
    mapping = cast(dict[object, object], value)
    if any(not isinstance(key, str) for key in mapping):
        raise ValueError("Expected string object keys")
    return cast(dict[str, object], mapping)


def _array(value: object) -> list[object]:
    if not isinstance(value, list):
        raise ValueError("Expected a JSON array")
    return cast(list[object], value)


def _string(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError("Expected a JSON string")
    return value


def _number(value: object) -> float:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not isfinite(value)
    ):
        raise ValueError("Expected a finite JSON number")
    return float(value)


def _field(mapping: dict[str, object], name: str) -> object:
    if name not in mapping:
        raise ValueError(f"Missing required field {name!r}")
    return mapping[name]


def _geometry(value: object) -> Geometry:
    mapping = _object(value)
    kind = _string(_field(mapping, "kind"))
    if kind not in ("polygon", "polyline", "buffer"):
        raise ValueError(f"Unsupported geometry kind {kind!r}")
    coordinates: list[tuple[float, float]] = []
    for raw_pair in _array(_field(mapping, "coordinates")):
        pair = _array(raw_pair)
        if len(pair) != 2:
            raise ValueError("Coordinates must be x/y pairs")
        coordinates.append((_number(pair[0]), _number(pair[1])))
    raw_width = _field(mapping, "buffer_width_m")
    return Geometry(
        kind,
        tuple(coordinates),
        None if raw_width is None else _number(raw_width),
    )


def read_observation(path: Path) -> CoverageObservation:
    raw: object = json.loads(path.read_text(encoding="utf-8"))
    mapping = _object(raw)
    if _field(mapping, "source") != "synthetic":
        raise ValueError(
            "Only this prototype's synthetic observation schema is supported"
        )
    parameters = _object(_field(mapping, "parameters"))
    records: list[CoverageRecord] = []
    for item in _array(_field(mapping, "records")):
        record = _object(item)
        signals: list[Signal] = []
        for signal_value in _array(_field(record, "cells")):
            signal = _object(signal_value)
            signals.append(
                Signal(
                    _string(_field(signal, "cell_id")),
                    _number(_field(signal, "rsrp_dbm")),
                    _number(_field(signal, "rsrq_db")),
                )
            )
        status = _string(_field(record, "status"))
        if status not in ("valid", "missing"):
            raise ValueError(f"Invalid record status {status!r}")
        demand = _field(record, "down_cell_traffic_mbps")
        records.append(
            CoverageRecord(
                _string(_field(record, "grid_id")),
                status,
                tuple(signals),
                None if demand is None else _number(demand),
            )
        )
    result_status = _string(_field(mapping, "result_status"))
    if result_status not in ("complete", "partial_missing", "all_missing"):
        raise ValueError(f"Invalid query result status {result_status!r}")
    return CoverageObservation(
        id=_string(_field(mapping, "id")),
        source="synthetic",
        parameters=QueryParameters(
            reference_id=_string(_field(parameters, "reference_id")),
            geometry=_geometry(_field(parameters, "geometry")),
            grid_ids=tuple(
                _string(item) for item in _array(_field(parameters, "grid_ids"))
            ),
            coordinate_system=_string(_field(parameters, "coordinate_system")),
            coverage_epoch=_string(_field(parameters, "coverage_epoch")),
        ),
        result_status=result_status,
        records=tuple(records),
    )


def load_observations(
    state: State, output_root: Path
) -> dict[str, CoverageObservation]:
    """Find the raw query records by following a state's persisted provenance links."""
    observations: dict[str, CoverageObservation] = {}
    for link in state.observations:
        relative_path = Path(link.path)
        if relative_path.is_absolute() or ".." in relative_path.parts:
            raise ValueError(
                "Observation links must be relative to the output directory"
            )
        observation = read_observation(output_root / relative_path)
        if observation.id != link.observation_id:
            raise ValueError("Observation ID does not match state link")
        observations[observation.id] = observation
    return observations
