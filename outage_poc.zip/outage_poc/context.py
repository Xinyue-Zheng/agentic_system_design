"""Deterministic, text-only descriptions of evidence already present in state."""

from .models import RegionSummary, State


def _number(value: float) -> str:
    return f"{value:g}"


def _region_lines(region: RegionSummary, down_cell_id: str) -> list[str]:
    total = len(region.total_ids)
    queried = len(region.queried_ids)
    valid = len(region.valid_ids)
    lines = [
        (
            f"- {region.reference_id} contains {total} analysis grid locations: "
            f"{queried} queried, {len(region.unqueried_ids)} not queried."
        ),
    ]
    if queried:
        if valid == queried:
            lines.append(f"  All {queried} queried locations have valid data.")
        else:
            lines.append(
                f"  {valid} queried locations have valid data; "
                f"{len(region.missing_ids)} have missing data."
            )
        lines.append(
            f"  Valid records: {len(region.valid_covered_ids)} have cell coverage; "
            f"{len(region.no_coverage_ids)} have no cell coverage; "
            f"{len(region.other_cells_only_ids)} have other cells but no {down_cell_id}."
        )
    return lines


def _coverage_lines(region: RegionSummary, down_cell_id: str) -> list[str]:
    queried = len(region.queried_ids)
    if not queried:
        return [f"- {region.reference_id}: coverage is unknown; no locations queried."]
    lines = [
        (
            f"- {region.reference_id}: {down_cell_id} is present at "
            f"{len(region.target_ids)} of the {queried} queried locations."
        )
    ]
    if region.target_ids:
        if region.target_rsrp_min_dbm is None or region.target_rsrp_max_dbm is None:
            raise ValueError(
                "Target signal bounds are required for observed target cells."
            )
        lines.append(
            "  Its RSRP at these locations ranges from "
            f"{_number(region.target_rsrp_min_dbm)} to "
            f"{_number(region.target_rsrp_max_dbm)} dBm."
        )
    if region.boundary_ids:
        lines.append(
            "  Along the query boundary facing the unqueried interior, "
            f"{down_cell_id} is present at {len(region.boundary_target_ids)} "
            f"of {len(region.boundary_ids)} boundary locations "
            f"({len(region.boundary_valid_ids)} valid, "
            f"{len(region.boundary_missing_ids)} missing)."
        )
    else:
        lines.append(
            "  No queried/unqueried interior boundary exists in this reference."
        )
    if region.unqueried_ids:
        lines.append("  Coverage in the unqueried interior remains unknown.")
    if region.missing_ids:
        lines.append("  Coverage at locations with missing data also remains unknown.")
    return lines


def render_context(state: State) -> str:
    """Describe facts, scope, evidence references, and unknowns without choosing an action."""
    down_cell_id = state.task.down_cell_id
    summaries = {region.reference_id: region for region in state.regions}
    lines = [
        "Task:",
        f"Investigate the outage impact of cell {down_cell_id}.",
        f"Outage time: {state.task.outage_time}.",
        f"Analysis objective: {state.task.objective}",
        (
            "This is a synthetic investigation. Coverage describes the pre-outage network; "
            f"{down_cell_id} is unavailable after the outage."
        ),
        "",
        "Known geography:",
        (
            f"Coordinate system: {state.coordinate_system}; grid spacing "
            f"{_number(state.grid_spacing_m)} m. Coordinates are not latitude/longitude."
        ),
    ]
    for item in state.geography:
        lines.append(f"- {item.id} is a {item.kind}. {item.description}")
        if item.geometry.kind == "polyline":
            lines.append(
                f"  {item.id} has a known road centerline, not an area boundary."
            )
        else:
            lines.append(f"  Geographic geometry is available for {item.id}.")
    for relation in state.relations:
        lines.append(
            f"- {relation.subject_id} {relation.predicate} {relation.object_id}. "
            f"Spatial evidence: {relation.evidence}"
        )
    lines.extend(
        [
            (
                "Land-use labels identify mapped types only: they do not establish "
                "population, complete network demand, or zero demand in farmland/forest."
            ),
            "",
            "Investigation progress:",
            "Counts are per reference; overlapping references must not be added together.",
        ]
    )
    for region in state.regions:
        lines.extend(_region_lines(region, down_cell_id))
    lines.extend(
        [
            "",
            "Coverage observations:",
            (
                "Boundary rule: within each reference, a queried grid location is on the "
                "interior frontier if at least one of its four orthogonal grid neighbors "
                "in the same reference is unqueried. Signal presence never selects the boundary."
            ),
            "Missing boundary records are unknown, not target-absent observations.",
        ]
    )
    for region in state.regions:
        lines.extend(_coverage_lines(region, down_cell_id))
    lines.extend(["", "Impact and backup analysis:"])
    impact = state.impact
    if impact is None:
        lines.append(
            "Backup selection, traffic transfer, and load estimation have not been performed."
        )
    else:
        lines.extend(
            [
                (
                    f"Scope: {impact.parameters.scope_reference_id}, "
                    f"{len(impact.scope_queried_ids)} queried locations; "
                    f"{len(impact.excluded_unqueried_ids)} unqueried and "
                    f"{len(impact.excluded_missing_ids)} missing locations excluded."
                ),
                (
                    f"Observed target locations: {impact.target_location_count}; synthetic "
                    f"target traffic: {_number(impact.total_target_traffic_mbps)} Mbps; "
                    f"unserved: {_number(impact.unserved_traffic_mbps)} Mbps."
                ),
                f"Backup selection: {impact.parameters.selection_rule}",
                (
                    f"Eligibility thresholds: RSRP >= {_number(impact.parameters.minimum_rsrp_dbm)} "
                    f"dBm and RSRQ >= {_number(impact.parameters.minimum_rsrq_db)} dB."
                ),
                f"Load formula: {impact.parameters.load_formula}",
                "Location share and traffic share have separate denominators and need not agree.",
            ]
        )
        for backup in impact.backup_loads:
            lines.append(
                f"- {backup.cell_id}: {backup.assigned_locations} assigned locations "
                f"({backup.location_share:.2%} of observed target locations), "
                f"{_number(backup.transferred_mbps)} Mbps transferred "
                f"({backup.traffic_share:.2%} of observed target traffic); "
                f"baseline PRB {_number(backup.baseline_prb_percent)}%, "
                f"capacity {_number(backup.capacity_mbps)} Mbps, "
                f"estimated PRB {_number(backup.estimated_prb_percent)}%; "
                f"exceeds capacity: {str(backup.exceeds_capacity).lower()}."
            )
        lines.extend(f"- Limitation: {limitation}" for limitation in impact.limitations)
    lines.extend(["", "Remaining unknowns:"])
    lines.extend(f"- {unknown}" for unknown in state.unknowns)
    lines.extend(["", "Available geographic references:"])
    for reference in state.references:
        region = summaries[reference.id]
        lines.append(
            f"- {reference.id}: {reference.description} "
            f"Resolves to {len(reference.grid_ids)} actual grid locations; "
            f"{len(region.queried_ids)} queried, {len(region.unqueried_ids)} unqueried."
        )
        if reference.geometry.kind == "buffer":
            width = reference.geometry.buffer_width_m
            if width is None or width <= 0:
                raise ValueError(
                    "Road buffer references require a positive full width."
                )
            lines.append(
                f"  Coverage query area: road-centerline buffer with full width "
                f"{_number(width)} m (distance <= {_number(width / 2)} m from "
                "the centerline, including round end caps)."
            )
    lines.extend(["", "Evidence provenance:"])
    for observation in state.observations:
        lines.append(
            f"- {observation.observation_id}: {observation.path}; "
            f"reference {observation.reference_id}; {len(observation.grid_ids)} returned locations."
        )
    lines.extend(
        [
            (
                "The state evidence index maps each queried location to its observation; "
                "full cell lists and measurements remain in those query results."
            ),
            (
                "This text is a deterministic context preview, not a request sent to a model. "
                "Maps are for human inspection and are not model evidence."
            ),
            "",
        ]
    )
    return "\n".join(lines)
