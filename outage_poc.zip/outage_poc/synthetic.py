"""Deterministic synthetic inputs and an offline geometric coverage provider.

The record generator is deliberately separate from state and context. It models
pre-outage evidence only; its formulas are fictional, not a propagation model.
"""

from math import hypot, isfinite

from outage_poc.geometry import covers_point, geometries_intersect, select_grid
from outage_poc.models import (
    BaselineKPI,
    CoverageObservation,
    CoverageRecord,
    Dataset,
    GeographicReference,
    Geometry,
    GeoObject,
    GridPoint,
    QueryParameters,
    Signal,
    SpatialRelation,
    Task,
)

COORDINATE_SYSTEM = (
    "synthetic local planar coordinates in metres; not latitude/longitude"
)
COVERAGE_EPOCH = "pre_outage"


def _rectangle(left: float, bottom: float, right: float, top: float) -> Geometry:
    if left >= right or bottom >= top:
        raise ValueError("Rectangle bounds must have positive width and height")
    return Geometry(
        "polygon", ((left, bottom), (right, bottom), (right, top), (left, top)), None
    )


def _make_grid() -> tuple[GridPoint, ...]:
    return tuple(
        GridPoint(
            f"G_r{row:02d}_c{column:02d}",
            column * 100.0 + 50,
            row * 100.0 + 50,
            column,
            row,
        )
        for row in range(40)
        for column in range(60)
    )


def _make_geography() -> tuple[GeoObject, ...]:
    return (
        GeoObject(
            "Study_area",
            "study_area",
            "Synthetic rural study area; land use does not imply population or demand",
            _rectangle(0, 0, 6000, 4000),
        ),
        GeoObject(
            "S1",
            "settlement",
            "Synthetic settlement nearest the down cell",
            _rectangle(800, 1000, 1400, 1600),
        ),
        GeoObject(
            "S2",
            "settlement",
            "Synthetic settlement extending north from H2",
            _rectangle(4000, 1000, 4800, 3500),
        ),
        GeoObject(
            "S3",
            "settlement",
            "Synthetic northern settlement",
            _rectangle(800, 2900, 1600, 3500),
        ),
        GeoObject(
            "H1",
            "highway",
            "Synthetic highway centreline; query with H1_buffer (300 m full width)",
            Geometry("polyline", ((1100, 1200), (1100, 3300)), None),
        ),
        GeoObject(
            "H2",
            "highway",
            "Synthetic highway centreline; query with H2_buffer (500 m full width)",
            Geometry("polyline", ((1100, 1250), (4500, 1250)), None),
        ),
        GeoObject(
            "F1",
            "farmland",
            "Synthetic farmland; demand is not inferred from land use",
            _rectangle(1600, 0, 4000, 1000),
        ),
        GeoObject(
            "V1",
            "vineyard",
            "Synthetic vineyard; demand is not inferred from land use",
            _rectangle(1600, 1600, 3500, 2900),
        ),
        GeoObject(
            "F2",
            "forest",
            "Synthetic forest; demand is not assumed to be zero",
            _rectangle(4800, 2000, 6000, 4000),
        ),
        GeoObject(
            "D0",
            "cell",
            "Synthetic down cell marker",
            _rectangle(990, 1290, 1010, 1310),
        ),
        GeoObject(
            "B1",
            "cell",
            "Synthetic available backup marker",
            _rectangle(1590, 1590, 1610, 1610),
        ),
        GeoObject(
            "B2",
            "cell",
            "Synthetic available backup marker",
            _rectangle(4090, 1190, 4110, 1210),
        ),
        GeoObject(
            "B3",
            "cell",
            "Synthetic available backup marker",
            _rectangle(4590, 2790, 4610, 2810),
        ),
    )


def _make_references(
    grid: tuple[GridPoint, ...], geography: tuple[GeoObject, ...]
) -> tuple[GeographicReference, ...]:
    references: list[GeographicReference] = []
    for item in geography:
        if item.kind == "cell":
            continue
        if item.kind == "highway":
            width = {"H1": 300.0, "H2": 500.0}[item.id]
            geometry = Geometry("buffer", item.geometry.coordinates, width)
            reference_id = f"{item.id}_buffer"
            description = (
                f"Round-ended road corridor for {item.id}; full width {width:g} m"
            )
        else:
            geometry = item.geometry
            reference_id = item.id
            description = item.description
        references.append(
            GeographicReference(
                reference_id,
                description,
                geometry,
                select_grid(grid, geometry),
                None if item.id == "Study_area" else "Study_area",
            )
        )
    for reference_id, description, geometry in (
        (
            "S2_roadside",
            "Roadside section of S2 (southern five grid rows)",
            _rectangle(4000, 1000, 4800, 1500),
        ),
        (
            "S2_remaining",
            "Interior part of S2 beyond the roadside section; querying determines its coverage",
            _rectangle(4000, 1500, 4800, 3500),
        ),
    ):
        references.append(
            GeographicReference(
                reference_id, description, geometry, select_grid(grid, geometry), "S2"
            )
        )
    return tuple(references)


def _make_relations(geography: tuple[GeoObject, ...]) -> tuple[SpatialRelation, ...]:
    relations: list[SpatialRelation] = []
    study = next(item for item in geography if item.id == "Study_area")
    for item in geography:
        if item.id != study.id and all(
            covers_point(point, study.geometry) for point in item.geometry.coordinates
        ):
            relations.append(
                SpatialRelation(
                    study.id,
                    "contains",
                    item.id,
                    "All geometry vertices lie in the convex rectangular study area",
                )
            )
    for highway in (item for item in geography if item.kind == "highway"):
        for settlement in (item for item in geography if item.kind == "settlement"):
            if geometries_intersect(highway.geometry, settlement.geometry):
                relations.append(
                    SpatialRelation(
                        highway.id,
                        "intersects",
                        settlement.id,
                        "Polyline and polygon intersect in synthetic local metre coordinates",
                    )
                )
    return tuple(relations)


def _backup_signals(point: GridPoint) -> tuple[Signal, ...]:
    signals: list[Signal] = []
    for cell_id, x_m, y_m in (
        ("B1", 1600, 1600),
        ("B2", 4100, 1200),
        ("B3", 4600, 2800),
    ):
        distance = hypot(point.x_m - x_m, point.y_m - y_m)
        if distance <= 2300:
            signals.append(
                Signal(
                    cell_id,
                    round(-78 - distance / 60, 2),
                    round(-8 - distance / 330, 2),
                )
            )
    return tuple(signals)


def _make_record(point: GridPoint) -> CoverageRecord:
    """Generate spatially determined fictional measurements before any query."""
    x_m, y_m = point.x_m, point.y_m
    in_s2 = 4000 <= x_m <= 4800 and 1000 <= y_m <= 3500
    target_rsrp: float | None = None
    backups = _backup_signals(point)
    if in_s2:
        local_column, local_row = point.column - 40, point.row - 10
        if local_row < 5:
            if local_column < 4:
                target_rsrp = float(-111 + (local_row * 4 + local_column) % 8)
        else:
            if (local_column + 3 * local_row) % 19 == 0:
                return CoverageRecord(point.id, "missing", (), None)
            if (local_column + local_row) % 17 == 0:
                return CoverageRecord(point.id, "valid", (), 0.0)
            if local_row < 16 and local_column < 3:
                target_rsrp = float(-113 + (local_column + local_row) % 7)
    else:
        if (point.column * 3 + point.row * 5) % 97 == 0:
            return CoverageRecord(point.id, "missing", (), None)
        if (point.column + point.row * 3) % 53 == 0:
            return CoverageRecord(point.id, "valid", (), 0.0)
        distance = hypot(x_m - 1000, y_m - 1300)
        if distance <= 1450:
            target_rsrp = round(-79 - distance / 48, 2)
        elif 1200 <= x_m < 4000 and abs(y_m - 1250) <= 250:
            target_rsrp = round(-96 - (x_m - 1200) / 210, 2)
        if 800 <= x_m <= 1000 and 1000 <= y_m <= 1200:
            backups = ()
    if target_rsrp is None:
        return CoverageRecord(point.id, "valid", backups, 0.0)
    signals = (
        Signal("D0", target_rsrp, round(-9 - abs(target_rsrp + 80) / 6, 2)),
        *backups,
    )
    # Nonuniform explicit D0 demand; geography labels are not a population proxy.
    traffic = round(0.3 + ((point.column * 3 + point.row * 7) % 13) * 0.11, 2)
    return CoverageRecord(point.id, "valid", signals, traffic)


def validate_record(record: CoverageRecord, down_cell_id: str) -> None:
    if not record.grid_id:
        raise ValueError("Coverage record grid_id is empty")
    if record.status not in {"valid", "missing"}:
        raise ValueError(f"Unknown data status at {record.grid_id}")
    if record.status == "missing":
        if record.cells or record.down_cell_traffic_mbps is not None:
            raise ValueError("Missing records cannot contain signals or known demand")
        return
    traffic = record.down_cell_traffic_mbps
    if traffic is None or not isfinite(traffic) or traffic < 0:
        raise ValueError("Valid synthetic records require finite nonnegative demand")
    cell_ids = [signal.cell_id for signal in record.cells]
    if len(set(cell_ids)) != len(cell_ids) or any(not cell_id for cell_id in cell_ids):
        raise ValueError("Signal cell IDs must be nonempty and unique")
    if any(
        not isfinite(signal.rsrp_dbm) or not isfinite(signal.rsrq_db)
        for signal in record.cells
    ):
        raise ValueError("Signals require finite measured RSRP and RSRQ")
    if down_cell_id not in cell_ids and traffic != 0:
        raise ValueError(
            "D0 demand requires observed D0 presence in this synthetic model"
        )


def build_dataset() -> Dataset:
    """Generate fictional geography, a full regular grid and pre-outage inputs."""
    grid = _make_grid()
    geography = _make_geography()
    records = tuple(_make_record(point) for point in grid)
    task = Task(
        "D0",
        "2026-01-15T09:00:00Z",
        "Investigate the outage impact of cell D0 using synthetic pre-outage coverage and explicit synthetic demand.",
    )
    for record in records:
        validate_record(record, task.down_cell_id)
    return Dataset(
        task,
        100.0,
        grid,
        geography,
        _make_relations(geography),
        _make_references(grid, geography),
        records,
        (
            BaselineKPI("B1", 52.0, 70.0),
            BaselineKPI("B2", 68.0, 80.0),
            BaselineKPI("B3", 43.0, 65.0),
        ),
    )


def resolve_reference(dataset: Dataset, reference_id: str) -> QueryParameters:
    """Resolve a real named geographic reference to auditable tool parameters."""
    matches = [
        reference for reference in dataset.references if reference.id == reference_id
    ]
    if len(matches) != 1:
        raise ValueError(f"Expected one geographic reference for {reference_id!r}")
    reference = matches[0]
    actual_ids = select_grid(dataset.grid, reference.geometry)
    if actual_ids != reference.grid_ids:
        raise ValueError(
            f"Reference {reference_id} disagrees with its geometric selection"
        )
    if not actual_ids:
        raise ValueError(
            f"Reference {reference_id} contains no analysis grid locations"
        )
    return QueryParameters(
        reference.id, reference.geometry, actual_ids, COORDINATE_SYSTEM, COVERAGE_EPOCH
    )


def query_coverage(
    dataset: Dataset, parameters: QueryParameters, observation_id: str
) -> CoverageObservation:
    """Query the pre-generated records by geometry, independently of step IDs."""
    if not observation_id:
        raise ValueError("Observation ID cannot be empty")
    if parameters != resolve_reference(dataset, parameters.reference_id):
        raise ValueError(
            "Query parameters do not match the resolved geographic reference"
        )
    lookup = {record.grid_id: record for record in dataset.records}
    if len(lookup) != len(dataset.records):
        raise ValueError("Synthetic input has duplicate coverage grid IDs")
    if set(lookup) != {point.id for point in dataset.grid}:
        raise ValueError("Synthetic records must cover the entire analysis grid")
    # Selection is recomputed from actual geometry; no step identifier is consulted.
    selected_ids = select_grid(dataset.grid, parameters.geometry)
    records = tuple(lookup[grid_id] for grid_id in selected_ids)
    for record in records:
        validate_record(record, dataset.task.down_cell_id)
    missing = sum(record.status == "missing" for record in records)
    status = (
        "complete"
        if missing == 0
        else "all_missing"
        if missing == len(records)
        else "partial_missing"
    )
    return CoverageObservation(observation_id, "synthetic", parameters, status, records)
