"""Run with: uv run python -m outage_poc --output outputs/demo."""

import argparse
import sys
from pathlib import Path

from outage_poc.demo import run_demo


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run the deterministic offline synthetic outage demo."
    )
    parser.add_argument(
        "--output", required=True, type=Path, help="New or empty output directory"
    )
    arguments = parser.parse_args()
    output = arguments.output
    if not isinstance(output, Path):
        raise TypeError("--output must be a filesystem path")
    try:
        trace = run_demo(output)
    except (ValueError, OSError) as error:
        print(f"Demo failed: {error}", file=sys.stderr)
        return 1
    print(
        f"Completed {len(trace.steps)} scripted_demo steps (synthetic; no model calls)."
    )
    print(f"Human viewer: {output / 'index.html'}")
    print(f"S2 intermediate state: {output / 'states/state_04.json'}")
    print(f"S2 intermediate text: {output / 'contexts/state_04.txt'}")
    print(f"Execution trace: {output / 'trace.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
