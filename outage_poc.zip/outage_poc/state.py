"""Deterministic evidence accumulation; this module never reads hidden coverage."""

from dataclasses import replace
from datetime import datetime
from math import isfinite

from outage_poc.geometry import query_boundary, select_grid
from outage_poc.models import (
    BackupAssignment,
    BackupLoad,
    BaselineKPI,
    CoverageObservation,
    CoverageRecord,
    Dataset,
    GeographicReference,
    GridEvidence,
    GridPoint,
    ImpactAnalysis,
    LoadParameters,
    ObservationLink,
    RegionSummary,
    State,
)

COORDINATE_SYSTEM = (
    "synthetic local planar coordinates in metres; not latitude/longitude"
)
BACKUP_SELECTION_RULE = "strongest eligible RSRP; ties by cell ID; exclude down cell"
LOAD_FORMULA = "estimated_prb_percent = baseline_prb_percent + 100 * transferred_mbps / capacity_mbps"


def default_load_parameters(scope_reference_id: str) -> LoadParameters:
    return LoadParameters(
        scope_reference_id=scope_reference_id,
        minimum_rsrp_dbm=-112.0,
        minimum_rsrq_db=-16.0,
        selection_rule=BACKUP_SELECTION_RULE,
        load_formula=LOAD_FORMULA,
    )


def summary_for(state: State, reference_id: str) -> RegionSummary:
    matches = [
        region for region in state.regions if region.reference_id == reference_id
    ]
    if len(matches) != 1:
        raise ValueError(f"Expected one summary for reference {reference_id!r}")
    return matches[0]


def _summarize(
    reference: GeographicReference,
    grid: tuple[GridPoint, ...],
    records: dict[str, CoverageRecord],
    evidence: dict[str, str],
    target_cell: str,
) -> RegionSummary:
    total = set(reference.grid_ids)
    queried = total & records.keys()
    unqueried = total - queried
    valid = {point_id for point_id in queried if records[point_id].status == "valid"}
    missing = queried - valid
    covered = {point_id for point_id in valid if records[point_id].cells}
    target_signals = {
        point_id: signal
        for point_id in valid
        for signal in records[point_id].cells
        if signal.cell_id == target_cell
    }
    target = set(target_signals)
    rsrp = [signal.rsrp_dbm for signal in target_signals.values()]
    boundary = set(query_boundary(queried, unqueried, grid))
    return RegionSummary(
        reference_id=reference.id,
        total_ids=tuple(sorted(total)),
        queried_ids=tuple(sorted(queried)),
        unqueried_ids=tuple(sorted(unqueried)),
        valid_ids=tuple(sorted(valid)),
        missing_ids=tuple(sorted(missing)),
        valid_covered_ids=tuple(sorted(covered)),
        no_coverage_ids=tuple(sorted(valid - covered)),
        other_cells_only_ids=tuple(sorted(covered - target)),
        target_ids=tuple(sorted(target)),
        target_rsrp_min_dbm=min(rsrp) if rsrp else None,
        target_rsrp_max_dbm=max(rsrp) if rsrp else None,
        boundary_ids=tuple(sorted(boundary)),
        boundary_valid_ids=tuple(sorted(boundary & valid)),
        boundary_missing_ids=tuple(sorted(boundary & missing)),
        boundary_target_ids=tuple(sorted(boundary & target)),
        observation_ids=tuple(sorted({evidence[point_id] for point_id in queried})),
    )


def _unknowns(regions: tuple[RegionSummary, ...], has_impact: bool) -> tuple[str, ...]:
    notes: list[str] = []
    for region in regions:
        if region.unqueried_ids:
            notes.append(
                f"{region.reference_id}: coverage at {len(region.unqueried_ids)} "
                "unqueried locations is unknown."
            )
        if region.missing_ids:
            notes.append(
                f"{region.reference_id}: coverage at {len(region.missing_ids)} "
                "queried locations with missing data is unknown."
            )
    if not has_impact:
        notes.append(
            "Backup selection, traffic transfer and load have not been computed."
        )
    notes.extend(
        (
            "Coverage beyond the study area is unknown.",
            "Land-use labels do not establish population or complete network demand.",
            "Investigation sufficiency has not been assessed; no stopping rule is implemented.",
        )
    )
    return tuple(notes)


def initial_state(dataset: Dataset) -> State:
    """Only copy public geography and task metadata, never dataset.records or KPIs."""
    if not dataset.task.down_cell_id or not dataset.task.objective:
        raise ValueError("Task requires a down cell and objective")
    outage_time = datetime.fromisoformat(dataset.task.outage_time)
    if outage_time.tzinfo is None:
        raise ValueError("Outage time must include a timezone")
    if not isfinite(dataset.grid_spacing_m) or dataset.grid_spacing_m <= 0:
        raise ValueError("Grid spacing must be finite and positive")
    grid_ids = {point.id for point in dataset.grid}
    if not grid_ids or len(grid_ids) != len(dataset.grid):
        raise ValueError("Grid IDs must be nonempty and unique")
    coordinates = {(point.column, point.row) for point in dataset.grid}
    if len(coordinates) != len(dataset.grid):
        raise ValueError("Grid row/column addresses must be unique")
    reference_ids = [reference.id for reference in dataset.references]
    if (
        len(set(reference_ids)) != len(reference_ids)
        or "Study_area" not in reference_ids
    ):
        raise ValueError("Unique references including Study_area are required")
    for reference in dataset.references:
        if not reference.grid_ids or len(set(reference.grid_ids)) != len(
            reference.grid_ids
        ):
            raise ValueError(f"Empty or duplicate grid set in reference {reference.id}")
        if set(select_grid(dataset.grid, reference.geometry)) != set(
            reference.grid_ids
        ):
            raise ValueError(
                f"Reference geometry and grid set disagree: {reference.id}"
            )
        if reference.parent_id is not None and reference.parent_id not in reference_ids:
            raise ValueError(f"Unknown parent reference: {reference.parent_id}")
    regions = tuple(
        _summarize(reference, dataset.grid, {}, {}, dataset.task.down_cell_id)
        for reference in dataset.references
    )
    if (
        set(next(r for r in regions if r.reference_id == "Study_area").total_ids)
        != grid_ids
    ):
        raise ValueError("Study_area must contain the complete analysis grid")
    return State(
        id="state_00",
        source="synthetic",
        task=dataset.task,
        coordinate_system=COORDINATE_SYSTEM,
        grid_spacing_m=dataset.grid_spacing_m,
        grid=dataset.grid,
        geography=dataset.geography,
        relations=dataset.relations,
        references=dataset.references,
        regions=regions,
        observations=(),
        evidence=(),
        impact=None,
        unknowns=_unknowns(regions, has_impact=False),
    )


def validate_observation(observation: CoverageObservation, state: State) -> None:
    """Validate the tool contract, including a record for every requested point."""
    if not observation.id or observation.source != "synthetic":
        raise ValueError("Expected an identified synthetic observation")
    parameters = observation.parameters
    references = {reference.id: reference for reference in state.references}
    if parameters.reference_id not in references:
        raise ValueError(f"Unknown geographic reference {parameters.reference_id}")
    reference = references[parameters.reference_id]
    if parameters.geometry != reference.geometry:
        raise ValueError("Observation query geometry differs from the named reference")
    if len(set(parameters.grid_ids)) != len(parameters.grid_ids):
        raise ValueError("Duplicate requested grid IDs")
    if set(parameters.grid_ids) != set(reference.grid_ids):
        raise ValueError("Observation grid set differs from the named reference")
    if parameters.coordinate_system != state.coordinate_system:
        raise ValueError("Query coordinate system does not match state")
    if parameters.coverage_epoch != "pre_outage":
        raise ValueError("This investigation requires pre-outage coverage evidence")
    record_ids = [record.grid_id for record in observation.records]
    if len(set(record_ids)) != len(record_ids) or set(record_ids) != set(
        parameters.grid_ids
    ):
        raise ValueError(
            "Coverage result must contain exactly one record per requested grid ID"
        )
    missing = 0
    for record in observation.records:
        if record.status == "missing":
            missing += 1
            if record.cells or record.down_cell_traffic_mbps is not None:
                raise ValueError(
                    "Missing data cannot contain signals or demand estimates"
                )
        elif record.status == "valid":
            traffic = record.down_cell_traffic_mbps
            if traffic is None or not isfinite(traffic) or traffic < 0:
                raise ValueError(
                    "Valid synthetic records require finite nonnegative demand"
                )
            if len({signal.cell_id for signal in record.cells}) != len(record.cells):
                raise ValueError("A coverage record cannot list duplicate cell IDs")
            for signal in record.cells:
                if (
                    not signal.cell_id
                    or not isfinite(signal.rsrp_dbm)
                    or not isfinite(signal.rsrq_db)
                ):
                    raise ValueError("Signals require a cell ID and finite RSRP/RSRQ")
            if (
                not any(s.cell_id == state.task.down_cell_id for s in record.cells)
                and traffic != 0
            ):
                raise ValueError(
                    "Synthetic down-cell demand requires down-cell coverage evidence"
                )
        else:
            raise ValueError(f"Invalid coverage status: {record.status}")
    expected_status = (
        "all_missing"
        if missing == len(record_ids)
        else "partial_missing"
        if missing
        else "complete"
    )
    if observation.result_status != expected_status:
        raise ValueError("Result status disagrees with point records")


def records_from_state(
    state: State, observations: dict[str, CoverageObservation]
) -> dict[str, CoverageRecord]:
    """Resolve observed points through state provenance, ignoring unlinked results."""
    index: dict[str, dict[str, CoverageRecord]] = {}
    links: dict[str, ObservationLink] = {}
    for link in state.observations:
        if link.observation_id in links:
            raise ValueError("Duplicate observation links in state")
        links[link.observation_id] = link
        if link.observation_id not in observations:
            raise ValueError(f"Missing source observation: {link.observation_id}")
        observation = observations[link.observation_id]
        validate_observation(observation, state)
        if observation.id != link.observation_id:
            raise ValueError("Observation index key does not match result ID")
        if observation.parameters.reference_id != link.reference_id:
            raise ValueError("Observation link does not match query reference")
        if set(link.grid_ids) != set(observation.parameters.grid_ids):
            raise ValueError("Observation link does not match query grid")
        index[observation.id] = {
            record.grid_id: record for record in observation.records
        }
    records: dict[str, CoverageRecord] = {}
    for evidence in state.evidence:
        if evidence.grid_id in records:
            raise ValueError("Duplicate point evidence in state")
        if (
            evidence.observation_id not in index
            or evidence.grid_id not in index[evidence.observation_id]
        ):
            raise ValueError(f"Unresolvable observation evidence: {evidence.grid_id}")
        records[evidence.grid_id] = index[evidence.observation_id][evidence.grid_id]
    linked_grid_ids = {
        grid_id for link in state.observations for grid_id in link.grid_ids
    }
    if records.keys() != linked_grid_ids:
        raise ValueError("State evidence does not match queried grid union")
    expected_owners = {
        grid_id: link.observation_id
        for link in state.observations
        for grid_id in link.grid_ids
    }
    if any(
        evidence.observation_id != expected_owners[evidence.grid_id]
        for evidence in state.evidence
    ):
        raise ValueError("State evidence must use the latest observation for each grid")
    expected_regions = tuple(
        _summarize(
            reference, state.grid, records, expected_owners, state.task.down_cell_id
        )
        for reference in state.references
    )
    if expected_regions != state.regions:
        raise ValueError(
            "State summaries disagree with the linked observation evidence"
        )
    return records


def apply_coverage(
    state: State,
    observation: CoverageObservation,
    observation_path: str,
    state_id: str,
    observations: dict[str, CoverageObservation],
) -> State:
    if not state_id or state_id == state.id or not observation_path:
        raise ValueError("A new state ID and observation path are required")
    if any(link.observation_id == observation.id for link in state.observations):
        raise ValueError("Each query execution requires a new observation ID")
    if (
        observation.id not in observations
        or observations[observation.id] != observation
    ):
        raise ValueError("The observation must be registered before applying it")
    validate_observation(observation, state)
    records = records_from_state(state, observations)
    records.update({record.grid_id: record for record in observation.records})
    evidence = {item.grid_id: item.observation_id for item in state.evidence}
    evidence.update({record.grid_id: observation.id for record in observation.records})
    regions = tuple(
        _summarize(reference, state.grid, records, evidence, state.task.down_cell_id)
        for reference in state.references
    )
    return replace(
        state,
        id=state_id,
        regions=regions,
        observations=state.observations
        + (
            ObservationLink(
                observation.id,
                observation_path,
                observation.parameters.reference_id,
                observation.parameters.grid_ids,
            ),
        ),
        evidence=tuple(
            GridEvidence(grid_id, evidence[grid_id]) for grid_id in sorted(evidence)
        ),
        # A new spatial observation invalidates any derived load estimate.
        impact=None,
        unknowns=_unknowns(regions, has_impact=False),
    )


def estimate_impact(
    state: State,
    observations: dict[str, CoverageObservation],
    baseline_kpis: tuple[BaselineKPI, ...],
    parameters: LoadParameters,
) -> ImpactAnalysis:
    if (
        parameters.selection_rule != BACKUP_SELECTION_RULE
        or parameters.load_formula != LOAD_FORMULA
    ):
        raise ValueError("Unsupported backup selection rule or load formula")
    if not isfinite(parameters.minimum_rsrp_dbm) or not isfinite(
        parameters.minimum_rsrq_db
    ):
        raise ValueError("Backup thresholds must be finite")
    scope = summary_for(state, parameters.scope_reference_id)
    if not scope.queried_ids:
        raise ValueError("Impact estimation requires queried spatial evidence")
    records = records_from_state(state, observations)
    kpis = {kpi.cell_id: kpi for kpi in baseline_kpis}
    if not kpis or len(kpis) != len(baseline_kpis):
        raise ValueError("Baseline KPIs must have unique cell IDs")
    for kpi in baseline_kpis:
        if (
            not kpi.cell_id
            or not isfinite(kpi.baseline_prb_percent)
            or not 0 <= kpi.baseline_prb_percent <= 100
            or not isfinite(kpi.capacity_mbps)
            or kpi.capacity_mbps <= 0
        ):
            raise ValueError(f"Invalid synthetic baseline KPI: {kpi.cell_id}")
    assignments: list[BackupAssignment] = []
    for grid_id in scope.target_ids:
        record = records[grid_id]
        traffic = record.down_cell_traffic_mbps
        if record.status != "valid" or traffic is None:
            raise ValueError(
                "Target summary must resolve to valid coverage and traffic evidence"
            )
        eligible = [
            signal
            for signal in record.cells
            if signal.cell_id != state.task.down_cell_id
            and signal.rsrp_dbm >= parameters.minimum_rsrp_dbm
            and signal.rsrq_db >= parameters.minimum_rsrq_db
        ]
        winner = sorted(eligible, key=lambda signal: (-signal.rsrp_dbm, signal.cell_id))
        backup_id = winner[0].cell_id if winner else None
        if backup_id is not None and backup_id not in kpis:
            raise ValueError(f"No baseline KPI for selected backup {backup_id}")
        assignments.append(
            BackupAssignment(
                grid_id,
                backup_id,
                "transferred" if backup_id is not None else "no_eligible_backup",
                traffic,
            )
        )
    total_traffic = sum(assignment.traffic_mbps for assignment in assignments)
    loads: list[BackupLoad] = []
    for cell_id, kpi in sorted(kpis.items()):
        if cell_id == state.task.down_cell_id:
            continue
        assigned = [
            assignment
            for assignment in assignments
            if assignment.backup_cell_id == cell_id
        ]
        transferred = sum(assignment.traffic_mbps for assignment in assigned)
        estimated_prb = kpi.baseline_prb_percent + 100 * transferred / kpi.capacity_mbps
        loads.append(
            BackupLoad(
                cell_id=cell_id,
                assigned_locations=len(assigned),
                location_share=len(assigned) / len(assignments) if assignments else 0.0,
                transferred_mbps=transferred,
                traffic_share=transferred / total_traffic if total_traffic > 0 else 0.0,
                baseline_prb_percent=kpi.baseline_prb_percent,
                capacity_mbps=kpi.capacity_mbps,
                estimated_prb_percent=estimated_prb,
                exceeds_capacity=estimated_prb > 100,
            )
        )
    return ImpactAnalysis(
        source="synthetic",
        parameters=parameters,
        scope_queried_ids=scope.queried_ids,
        excluded_missing_ids=scope.missing_ids,
        excluded_unqueried_ids=scope.unqueried_ids,
        target_location_count=len(assignments),
        total_target_traffic_mbps=total_traffic,
        unserved_traffic_mbps=sum(
            a.traffic_mbps for a in assignments if a.backup_cell_id is None
        ),
        assignments=tuple(assignments),
        backup_loads=tuple(loads),
        baseline_kpis=baseline_kpis,
        limitations=(
            "Scope: only queried valid target-present locations in the named reference; not complete outage impact.",
            "Target presence is used as a synthetic affected-demand proxy, not proof of real serving-cell assignment.",
            "Location shares divide by valid target-present locations; traffic shares divide by their synthetic offered Mbps.",
            "A zero denominator is reported as share 0 with the zero denominator retained explicitly.",
            "Pre-outage locations with no coverage are not newly attributed to this outage.",
            "Missing and unqueried demand is excluded, not assumed to be zero.",
            "PRB-only linear demonstration; no RRC input, radio scheduling, mobility or calibrated network model.",
            "Estimated PRB above 100 percent flags potential overload and is not clamped.",
        ),
    )


def apply_impact(
    state: State,
    impact: ImpactAnalysis,
    state_id: str,
    observations: dict[str, CoverageObservation],
) -> State:
    if not state_id or state_id == state.id:
        raise ValueError("A new state ID is required")
    expected = estimate_impact(
        state, observations, impact.baseline_kpis, impact.parameters
    )
    if impact != expected:
        raise ValueError(
            "Impact is invalid or stale for the current observation evidence"
        )
    return replace(
        state,
        id=state_id,
        impact=impact,
        unknowns=_unknowns(state.regions, has_impact=True),
    )
