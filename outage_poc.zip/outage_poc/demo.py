"""Explicit scripted actions. The state and generic skill do not select actions."""

from importlib.resources import files
from pathlib import Path

from outage_poc.context import render_context
from outage_poc.models import Action, State, Step, Trace
from outage_poc.persistence import (
    load_observations,
    read_observation,
    write_json,
    write_text,
)
from outage_poc.render import render_map, render_page
from outage_poc.state import (
    apply_coverage,
    apply_impact,
    default_load_parameters,
    estimate_impact,
    initial_state,
)
from outage_poc.synthetic import build_dataset, query_coverage, resolve_reference

# This is a demonstration sequence, not an autonomous policy or a historical human log.
SCRIPTED_QUERIES = (
    "S1",
    "H1_buffer",
    "H2_buffer",
    "S2_roadside",
    "S2_remaining",
    "S3",
    "S2_roadside",  # Deliberate overlap demonstrates deduplication and provenance.
)


def _save_state(output: Path, state: State) -> tuple[str, str]:
    state_path = f"states/{state.id}.json"
    context_path = f"contexts/{state.id}.txt"
    write_json(output / state_path, state)
    write_text(output / context_path, render_context(state))
    return state_path, context_path


def _preview(skill: str, state: State) -> str:
    return (
        "CONTEXT PREVIEW ONLY — no model call was made.\n"
        "Execution source: scripted_demo. This is the information available before the action.\n\n"
        f"FIXED INVESTIGATION SKILL\n{skill}\n\nCURRENT ORGANIZED STATE\n{render_context(state)}"
    )


def run_demo(output: Path) -> Trace:
    """Generate data, execute real range queries, derive snapshots and render artifacts."""
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise ValueError(f"Output must be a new or empty directory: {output}")
    output.mkdir(parents=True, exist_ok=True)
    dataset = build_dataset()
    write_json(output / "synthetic/raw_dataset.json", dataset)
    skill = (
        files("outage_poc")
        .joinpath("resources/investigation_skill.txt")
        .read_text(encoding="utf-8")
    )
    write_text(output / "fixed_skill.txt", skill)
    state = initial_state(dataset)
    initial_state_path, _ = _save_state(output, state)
    steps: list[Step] = []
    for number, reference_id in enumerate(SCRIPTED_QUERIES, start=1):
        step_id = f"step_{number:02d}"
        before_path = f"states/{state.id}.json"
        preview_path = f"previews/{step_id}.txt"
        write_text(output / preview_path, _preview(skill, state))
        parameters = resolve_reference(dataset, reference_id)
        observation = query_coverage(dataset, parameters, f"obs_{number:02d}")
        observation_path = f"observations/{observation.id}.json"
        write_json(output / observation_path, observation)
        # The updater uses persisted tool results, not the provider's hidden record table.
        observations = load_observations(state, output)
        observation = read_observation(output / observation_path)
        observations[observation.id] = observation
        state = apply_coverage(
            state, observation, observation_path, f"state_{number:02d}", observations
        )
        after_path, after_context = _save_state(output, state)
        visualization = f"maps/{step_id}.svg"
        write_text(output / visualization, render_map(state))
        step = Step(
            id=step_id,
            execution_source="scripted_demo",
            state_before=before_path,
            context_preview=preview_path,
            action=Action("coverage.query", parameters),
            observation=observation_path,
            state_after=after_path,
            context_after=after_context,
            visualization=visualization,
        )
        write_json(output / f"steps/{step_id}.json", step)
        steps.append(step)

    number = len(steps) + 1
    step_id = f"step_{number:02d}"
    before_path = f"states/{state.id}.json"
    preview_path = f"previews/{step_id}.txt"
    write_text(output / preview_path, _preview(skill, state))
    load_parameters = default_load_parameters("Study_area")
    observations = load_observations(state, output)
    impact = estimate_impact(
        state, observations, dataset.baseline_kpis, load_parameters
    )
    observation_path = f"observations/impact_{number:02d}.json"
    write_json(output / observation_path, impact)
    state = apply_impact(state, impact, f"state_{number:02d}", observations)
    after_path, after_context = _save_state(output, state)
    visualization = f"maps/{step_id}.svg"
    write_text(output / visualization, render_map(state))
    step = Step(
        id=step_id,
        execution_source="scripted_demo",
        state_before=before_path,
        context_preview=preview_path,
        action=Action("impact.estimate", load_parameters),
        observation=observation_path,
        state_after=after_path,
        context_after=after_context,
        visualization=visualization,
    )
    write_json(output / f"steps/{step_id}.json", step)
    steps.append(step)
    trace = Trace(
        source="synthetic",
        execution_source="scripted_demo",
        description=(
            "Offline synthetic execution record, not a resumable checkpoint. "
            "No LLM decisions or model requests. The script ending does not establish investigation sufficiency."
        ),
        initial_state=initial_state_path,
        fixed_skill="fixed_skill.txt",
        steps=tuple(steps),
    )
    write_json(output / "trace.json", trace)
    write_text(output / "index.html", render_page(output, trace))
    return trace
